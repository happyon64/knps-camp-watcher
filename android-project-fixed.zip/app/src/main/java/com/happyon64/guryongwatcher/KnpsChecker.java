package com.happyon64.guryongwatcher;

import android.text.Html;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class KnpsChecker {
    static final String RESERVATION_URL =
            "https://reservation.knps.or.kr/reservation/searchSimpleCampReservation.do";
    private static final String LIST_URL =
            "https://reservation.knps.or.kr/reservation/campsiteList.do";
    private static final String[] CATEGORIES = {"자동차야영장", "카라반", "특화야영장"};
    private static final Pattern ROW = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern CELL = Pattern.compile("(?is)<(?:th|td)\\b[^>]*>(.*?)</(?:th|td)>");
    private static final Pattern ICON = Pattern.compile("(?is)<i\\b([^>]*)>");
    private static final Pattern ATTR = Pattern.compile("(?is)\\b(title|class)\\s*=\\s*(['\"])(.*?)\\2");
    private static final Pattern DATE = Pattern.compile("(\\d{4}-\\d{2}-\\d{2})");

    private static final class FacilityLabel {
        final String category;
        final String name;
        FacilityLabel(String category, String name) {
            this.category = category;
            this.name = name;
        }
    }

    static final class Target {
        final String id;
        final String label;
        final List<String> nights;
        Target(String id, String label, String... nights) {
            this.id = id;
            this.label = label;
            this.nights = Arrays.asList(nights);
        }
    }

    static final class Facility {
        final String category;
        final String name;
        final Map<String, String> states;
        Facility(String category, String name, Map<String, String> states) {
            this.category = category;
            this.name = name;
            this.states = states;
        }
        String displayName() { return category + " " + name; }
    }

    static final class TargetResult {
        final Target target;
        final boolean scheduleOpen;
        final List<Facility> matches;
        TargetResult(Target target, boolean scheduleOpen, List<Facility> matches) {
            this.target = target;
            this.scheduleOpen = scheduleOpen;
            this.matches = matches;
        }
    }

    static final List<Target> TARGETS = Arrays.asList(
            new Target("2026-08-13-caravan-special", "8월 13일~14일 (1박)", "2026-08-13"),
            new Target("2026-08-22-caravan-special", "8월 22일~23일 (1박)", "2026-08-22"),
            new Target("2026-08-29-caravan-special", "8월 29일~30일 (1박)", "2026-08-29"),
            new Target("2026-09-04-two-nights", "9월 4일~6일 (2박)", "2026-09-04", "2026-09-05")
    );

    List<TargetResult> check() throws Exception {
        String html = download();
        List<Facility> facilities = parseFacilities(html);
        if (facilities.isEmpty()) throw new IllegalStateException("예약 시설 표를 읽지 못했습니다.");
        List<TargetResult> results = new ArrayList<>();
        for (Target target : TARGETS) {
            List<Facility> desired = new ArrayList<>();
            for (Facility facility : facilities) {
                if (facility.category.equals("카라반") || facility.category.equals("특화야영장")) {
                    desired.add(facility);
                }
            }
            boolean scheduleOpen = true;
            for (String night : target.nights) {
                boolean seen = false;
                for (Facility facility : desired) {
                    if (facility.states.containsKey(night)) { seen = true; break; }
                }
                if (!seen) { scheduleOpen = false; break; }
            }
            List<Facility> matches = new ArrayList<>();
            if (scheduleOpen) {
                for (Facility facility : desired) {
                    boolean available = true;
                    for (String night : target.nights) {
                        if (!"available".equals(facility.states.get(night))) {
                            available = false;
                            break;
                        }
                    }
                    if (available) matches.add(facility);
                }
            }
            results.add(new TargetResult(target, scheduleOpen, matches));
        }
        return results;
    }

    private String download() throws Exception {
        String form = "dept_id=B101001"
                + "&dept_name=" + URLEncoder.encode("구룡", "UTF-8")
                + "&parent_dept_name=" + URLEncoder.encode("치악산", "UTF-8")
                + "&prd_ctg_id=&isGreenpoint=N";
        HttpURLConnection connection = (HttpURLConnection) new URL(LIST_URL).openConnection();
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(60_000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        connection.setRequestProperty("Referer", RESERVATION_URL);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/130.0 Mobile Safari/537.36");
        try (java.io.OutputStream output = connection.getOutputStream()) {
            output.write(form.getBytes(StandardCharsets.UTF_8));
        }
        int status = connection.getResponseCode();
        InputStream stream = status >= 200 && status < 300
                ? connection.getInputStream() : connection.getErrorStream();
        byte[] bytes = readAll(stream);
        if (status < 200 || status >= 300) {
            throw new IllegalStateException("국립공원 예약 서버 응답 오류: " + status);
        }
        String contentType = connection.getContentType();
        Charset charset = StandardCharsets.UTF_8;
        if (contentType != null) {
            Matcher matcher = Pattern.compile("(?i)charset=([\\w-]+)").matcher(contentType);
            if (matcher.find()) {
                try { charset = Charset.forName(matcher.group(1)); } catch (Exception ignored) { }
            }
        }
        String text = new String(bytes, charset);
        if (!text.contains("시설명") && Charset.isSupported("MS949")) {
            String legacy = new String(bytes, Charset.forName("MS949"));
            if (legacy.contains("시설명")) text = legacy;
        }
        return text;
    }

    private static byte[] readAll(InputStream input) throws Exception {
        if (input == null) return new byte[0];
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    private List<Facility> parseFacilities(String html) {
        String namesTable = tableContaining(html, "시설명 및 영지 명");
        String statesTable = tableContaining(html, "시설 예약 현황");
        if (namesTable == null || statesTable == null) return Collections.emptyList();
        List<String> nameRows = rows(namesTable);
        List<String> statusRows = rows(statesTable);

        // The two visual tables do not always have the same number of header rows.
        // Build the facility labels first, then match each status row by the facility
        // name embedded in an icon title (for example "8호(6인) : 2026-08-13").
        // Falling back to row position made the Android app associate availability
        // icons with the wrong facility whenever KNPS changed a header row.
        List<FacilityLabel> facilityLabels = new ArrayList<>();
        String currentCategory = null;
        for (String nameRow : nameRows) {
            List<String> labels = labels(nameRow);
            String combined = String.join(" ", labels);
            for (String category : CATEGORIES) if (combined.contains(category)) currentCategory = category;
            String name = null;
            for (String label : labels) {
                String candidate = label;
                for (String category : CATEGORIES) candidate = candidate.replace(category, "");
                candidate = normalize(candidate);
                if (!candidate.isEmpty()) { name = candidate; break; }
            }
            if (name == null || currentCategory == null) continue;
            facilityLabels.add(new FacilityLabel(currentCategory, name));
        }

        Map<String, FacilityLabel> labelsByName = new LinkedHashMap<>();
        for (FacilityLabel label : facilityLabels) labelsByName.put(normalizeName(label.name), label);

        List<Facility> facilities = new ArrayList<>();
        for (String statusRow : statusRows) {
            Map<String, String> states = iconStates(statusRow);
            if (states.isEmpty()) continue;
            String statusName = statusFacilityName(statusRow);
            FacilityLabel label = statusName == null ? null : labelsByName.get(normalizeName(statusName));
            if (label != null) facilities.add(new Facility(label.category, label.name, states));
        }

        // Compatibility fallback for an older KNPS fragment that omitted facility
        // names from icon titles. Only use positional matching when name matching
        // produced nothing at all.
        if (facilities.isEmpty()) {
            List<String> dataRows = new ArrayList<>();
            for (String statusRow : statusRows) {
                if (!iconStates(statusRow).isEmpty()) dataRows.add(statusRow);
            }
            int count = Math.min(facilityLabels.size(), dataRows.size());
            for (int i = 0; i < count; i++) {
                FacilityLabel label = facilityLabels.get(i);
                facilities.add(new Facility(label.category, label.name, iconStates(dataRows.get(i))));
            }
        }
        return facilities;
    }

    private static String statusFacilityName(String row) {
        Matcher iconMatcher = ICON.matcher(row);
        while (iconMatcher.find()) {
            Matcher attrMatcher = ATTR.matcher(iconMatcher.group(1));
            while (attrMatcher.find()) {
                if (!attrMatcher.group(1).equalsIgnoreCase("title")) continue;
                String title = normalize(Html.fromHtml(
                        attrMatcher.group(3), Html.FROM_HTML_MODE_LEGACY).toString());
                Matcher dateMatcher = DATE.matcher(title);
                if (!dateMatcher.find()) continue;
                String prefix = title.substring(0, dateMatcher.start())
                        .replaceAll("[:\\-\\s]+$", "");
                if (!prefix.isEmpty()) return prefix;
            }
        }
        return null;
    }

    private static String normalizeName(String value) {
        return normalize(value)
                .replaceAll("\\s*\\((?:\\d+)인\\)\\s*$", "")
                .replaceAll("\\s+", "");
    }

    private static String tableContaining(String html, String marker) {
        Matcher matcher = Pattern.compile("(?is)<table\\b[^>]*>.*?</table>").matcher(html);
        while (matcher.find()) {
            String table = matcher.group();
            String text = normalize(Html.fromHtml(table, Html.FROM_HTML_MODE_LEGACY).toString());
            if (text.contains(marker)) return table;
        }
        return null;
    }

    private static List<String> rows(String table) {
        List<String> values = new ArrayList<>();
        Matcher matcher = ROW.matcher(table);
        while (matcher.find()) values.add(matcher.group(1));
        return values;
    }

    private static List<String> labels(String row) {
        List<String> values = new ArrayList<>();
        Matcher matcher = CELL.matcher(row);
        while (matcher.find()) {
            String text = normalize(Html.fromHtml(matcher.group(1), Html.FROM_HTML_MODE_LEGACY).toString());
            if (!text.isEmpty()) values.add(text);
        }
        return values;
    }

    private static Map<String, String> iconStates(String row) {
        Map<String, String> states = new LinkedHashMap<>();
        Matcher iconMatcher = ICON.matcher(row);
        while (iconMatcher.find()) {
            String title = "";
            String className = "";
            Matcher attrMatcher = ATTR.matcher(iconMatcher.group(1));
            while (attrMatcher.find()) {
                if (attrMatcher.group(1).toLowerCase(Locale.ROOT).equals("title")) title = attrMatcher.group(3);
                else className = attrMatcher.group(3);
            }
            Matcher dateMatcher = DATE.matcher(title);
            if (!dateMatcher.find()) continue;
            String status = "unknown";
            if (className.contains("icon-none-reservation")) status = "unavailable";
            else if (className.contains("icon-reservation")) status = "available";
            else if (className.contains("icon-waiting")) status = "waiting";
            else if (className.contains("icon-end")) status = "closed";
            states.put(dateMatcher.group(1), status);
        }
        return states;
    }

    private static String normalize(String value) {
        return value.replace('\u00a0', ' ').replaceAll("\\s+", " ").trim();
    }
}
