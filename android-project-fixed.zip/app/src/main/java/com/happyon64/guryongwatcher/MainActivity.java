package com.happyon64.guryongwatcher;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView statusView;
    private TextView batteryView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() { updateStatus(); handler.postDelayed(this, 1_000); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        requestNotificationPermission();
    }

    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }

    private View buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = text("구룡야영장 빈자리 알림", 26, true);
        root.addView(title);
        TextView description = text(
                "휴대폰에서 5분마다 카라반·특화야영장을 확인합니다. 빈자리가 발견되면 예약 링크가 포함된 알림을 보냅니다.",
                16, false);
        description.setPadding(0, dp(10), 0, dp(18));
        root.addView(description);

        statusView = text("상태 확인 중…", 18, true);
        statusView.setBackgroundColor(Color.rgb(238, 245, 250));
        statusView.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(statusView, matchWrap());

        batteryView = text("", 14, false);
        batteryView.setPadding(0, dp(10), 0, dp(10));
        root.addView(batteryView);

        Button start = button("감시 시작", v -> startMonitor(MonitorService.ACTION_START));
        Button check = button("지금 바로 확인", v -> startMonitor(MonitorService.ACTION_CHECK_NOW));
        Button stop = button("감시 중지", v -> {
            Intent intent = new Intent(this, MonitorService.class).setAction(MonitorService.ACTION_STOP);
            startService(intent);
        });
        Button battery = button("배터리 제한 해제", v -> requestBatteryExemption());
        Button reservation = button("국립공원 예약 페이지 열기", v ->
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(KnpsChecker.RESERVATION_URL))));
        root.addView(start, matchWrap());
        root.addView(check, matchWrap());
        root.addView(stop, matchWrap());
        root.addView(battery, matchWrap());
        root.addView(reservation, matchWrap());

        TextView targets = text(
                "감시 일정\n• 8월 13일~14일\n• 8월 22일~23일\n• 8월 29일~30일\n• 9월 4일~6일 (2박)\n\n대상: 카라반과 특화야영장 전체",
                16, false);
        targets.setPadding(0, dp(20), 0, dp(10));
        root.addView(targets);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void startMonitor(String action) {
        Intent intent = new Intent(this, MonitorService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void requestBatteryExemption() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager.isIgnoringBatteryOptimizations(getPackageName())) return;
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception error) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void updateStatus() {
        SharedPreferences prefs = getSharedPreferences(MonitorService.PREFS, Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean(MonitorService.KEY_ENABLED, false);
        long checked = prefs.getLong(MonitorService.KEY_LAST_CHECK, 0);
        String status = prefs.getString(MonitorService.KEY_LAST_STATUS, "아직 확인하지 않음");
        String error = prefs.getString(MonitorService.KEY_LAST_ERROR, "");
        String time = checked == 0 ? "-" : new SimpleDateFormat("M월 d일 HH:mm:ss", Locale.KOREA)
                .format(new Date(checked));
        statusView.setText((enabled ? "● 감시 실행 중" : "○ 감시 중지됨")
                + "\n" + status + "\n마지막 확인: " + time
                + (error.isEmpty() ? "" : "\n오류: " + error));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
            boolean exempt = manager.isIgnoringBatteryOptimizations(getPackageName());
            batteryView.setText(exempt
                    ? "✓ 배터리 제한이 해제되었습니다."
                    : "⚠ 정확한 감시를 위해 ‘배터리 제한 해제’를 눌러 주세요.");
        }
    }

    private Button button(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(8);
        button.setLayoutParams(params);
        return button;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(Color.rgb(25, 25, 25));
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
