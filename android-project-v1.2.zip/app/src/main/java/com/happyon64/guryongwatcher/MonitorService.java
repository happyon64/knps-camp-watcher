package com.happyon64.guryongwatcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class MonitorService extends Service {
    static final String PREFS = "monitor_state";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_LAST_CHECK = "last_check";
    static final String KEY_LAST_STATUS = "last_status";
    static final String KEY_LAST_ERROR = "last_error";
    static final String ACTION_START = "com.happyon64.guryongwatcher.START";
    static final String ACTION_STOP = "com.happyon64.guryongwatcher.STOP";
    static final String ACTION_CHECK_NOW = "com.happyon64.guryongwatcher.CHECK_NOW";

    private static final String STATUS_CHANNEL = "monitor_status";
    private static final String ALERT_CHANNEL = "vacancy_alerts";
    private static final int STATUS_ID = 1001;
    private static final long INTERVAL_MINUTES = 5L;

    private ScheduledExecutorService scheduler;
    private PowerManager.WakeLock wakeLock;
    private final AtomicBoolean checking = new AtomicBoolean(false);

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        startAsForeground("감시를 시작하는 중…");
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "GuryongWatcher:FiveMinuteMonitor");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(this::checkSafely, 0, INTERVAL_MINUTES, TimeUnit.MINUTES);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, true).apply();
        if (ACTION_CHECK_NOW.equals(action) && scheduler != null) scheduler.execute(this::checkSafely);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void checkSafely() {
        if (!checking.compareAndSet(false, true)) return;
        try {
            List<KnpsChecker.TargetResult> results = new KnpsChecker().check();
            processResults(results);
        } catch (Exception error) {
            String message = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
            saveState("확인 오류", message);
            updateStatus("확인 오류 · 다음 시각에 재시도");
        } finally {
            checking.set(false);
        }
    }

    private void processResults(List<KnpsChecker.TargetResult> results) {
        SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        List<String> allMatches = new ArrayList<>();
        for (KnpsChecker.TargetResult result : results) {
            List<String> names = new ArrayList<>();
            for (KnpsChecker.Facility facility : result.matches) names.add(facility.displayName());
            names.sort(String::compareTo);
            String key = String.join("|", names);
            String prefKey = "matches_" + result.target.id;
            String previousKey = preferences.getString(prefKey, "");
            preferences.edit().putString(prefKey, key).apply();
            if (!names.isEmpty()) {
                for (String name : names) allMatches.add(result.target.label + ": " + name);
                if (!key.equals(previousKey)) showVacancyAlert(result.target, names);
            }
        }
        String summary = allMatches.isEmpty()
                ? "빈자리 없음 · 5분마다 확인 중"
                : "빈자리 " + allMatches.size() + "개 감지";
        saveState(summary, "");
        updateStatus(summary);
    }

    private void saveState(String status, String error) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putLong(KEY_LAST_CHECK, System.currentTimeMillis())
                .putString(KEY_LAST_STATUS, status)
                .putString(KEY_LAST_ERROR, error)
                .apply();
    }

    private void showVacancyAlert(KnpsChecker.Target target, List<String> names) {
        String title = "구룡야영장 빈자리 발견!";
        String body = target.label + " · " + String.join(", ", names);
        PendingIntent reservation = PendingIntent.getActivity(this, target.id.hashCode(),
                new Intent(Intent.ACTION_VIEW, Uri.parse(KnpsChecker.RESERVATION_URL)),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = builder(ALERT_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(reservation)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_view, "예약하러 가기", reservation).build());
        getSystemService(NotificationManager.class).notify(2000 + Math.abs(target.id.hashCode() % 1000), builder.build());
    }

    private void startAsForeground(String text) {
        Notification notification = statusNotification(text);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(STATUS_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(STATUS_ID, notification);
        }
    }

    private void updateStatus(String text) {
        getSystemService(NotificationManager.class).notify(STATUS_ID, statusNotification(text));
    }

    private Notification statusNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, MonitorService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String time = new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date());
        return builder(STATUS_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setContentTitle("구룡야영장 감시 중")
                .setContentText(text + " · " + time)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "감시 중지", stopIntent).build())
                .build();
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel status = new NotificationChannel(
                STATUS_CHANNEL, "감시 실행 상태", NotificationManager.IMPORTANCE_LOW);
        status.setDescription("5분 간격 감시가 실행 중임을 표시합니다.");
        NotificationChannel alerts = new NotificationChannel(
                ALERT_CHANNEL, "빈자리 알림", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("카라반 또는 특화야영장 빈자리가 발견되면 알려줍니다.");
        alerts.enableVibration(true);
        getSystemService(NotificationManager.class).createNotificationChannels(Arrays.asList(status, alerts));
    }
}
