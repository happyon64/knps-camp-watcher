package com.happyon64.guryongwatcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean enabled = context.getSharedPreferences(MonitorService.PREFS, Context.MODE_PRIVATE)
                .getBoolean(MonitorService.KEY_ENABLED, false);
        if (!enabled) return;
        Intent service = new Intent(context, MonitorService.class);
        service.setAction(MonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
